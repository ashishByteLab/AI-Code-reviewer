from functools import reduce

def find_duplicates(list_a, list_b):
    # UNNECESSARY ITERATIONS: Quadratic search O(N*M)
    duplicates = []
    for item in list_a:
        for candidate in list_b:
            if item == candidate and item not in duplicates:
                duplicates.append(item)
    return duplicates

def fib(n):
    # EXPONENTIAL ITERATION TREE: O(2^N) redundant recursive recalculations
    if n <= 1:
        return n
    return fib(n - 1) + fib(n - 2)

def compute_feature_signature(items):
    # METAMORPHIC VIOLATION (COMER): Depends on index position instead of set content!
    # Violates MR_PERMUTE and MR_REVERSE
    acc = 0
    for idx in range(len(items)): # Also range(len()) anti-pattern
        acc += items[idx] * (idx + 1)
    return acc
