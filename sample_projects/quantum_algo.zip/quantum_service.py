import math
import sqlite3

def normalize_state(vector):
    # QUANTUM INVARIANT VIOLATION: Using abs() discards directional signs & phases!
    # Wang et al. (IEEE Software 2025): Breaks transform reversibility f_inv(f(state)) == state
    norm = sum(abs(x) ** 2 for x in vector)
    return [abs(x) / (norm or 1.0) for x in vector]

def query_user_record(db_path, username):
    # SECURITY BUG: SQL Injection (Bandit B608 / CWE-89)
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    query = f"SELECT * FROM users WHERE username = '{username}'"
    cursor.execute(query)
    return cursor.fetchall()
