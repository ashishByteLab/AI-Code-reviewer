import json
import time

def lambda_handler(event, context):
    # COLD START ANTI-PATTERN: Heavy imports inside handler (IEEE Access 2024)
    import math
    import urllib.parse
    
    # RECONNECTION OVERHEAD: Recreating client inside handler on every invocation
    db_conn = {'host': 'prod-db.internal', 'connected_at': time.time()}
    
    orders = event.get('orders', [])
    blacklist = ['FRAUD_01', 'FRAUD_02', 'BANNED_USR', 'BLOCKED_99'] * 20
    
    # UNNECESSARY ITERATION ANTI-PATTERN: Nested loop O(N * M)
    flagged = []
    for order in orders:
        for b in blacklist:
            if order == b:
                flagged.append(order)
                
    # STRING CONCATENATION IN LOOP: O(N^2) memory re-allocations
    audit_log = ''
    for o in flagged:
        audit_log += f'Flagged: {o}; '
        
    return {
        'statusCode': 200,
        'flagged_count': len(flagged),
        'audit': audit_log
    }
